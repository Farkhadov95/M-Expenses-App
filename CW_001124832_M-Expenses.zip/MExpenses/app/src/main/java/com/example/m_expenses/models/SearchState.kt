package com.example.m_expenses.models

data class SearchState(val name: String = "", val destination: String = "", val date: String = "")
